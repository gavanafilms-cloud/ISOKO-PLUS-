ISOKO PLUS — ACODE READY (SELF-CONTAINED PAGES)
=================================================

IMPORTANT: Every HTML page includes its own CSS and JavaScript.
You do NOT need to copy css/ or js/ files. This package is designed
to avoid Acode Preview failing to find linked CSS/JS files.

OPEN ON ANDROID / ACODE
1. Download this ZIP.
2. Extract it completely.
3. In Acode, use Open Folder and select ISOKO_PLUS_ACODE_READY.
4. Open index.html from that extracted folder.
5. Tap Preview.
6. Use the navigation links at the top or footer to open other pages.
7. Dashboard pages are inside the dashboards folder.

PAGES
index.html, buy.html, rent.html, categories.html, product.html,
about.html, contact.html, login.html, register.html, terms.html,
privacy.html, delivery.html,
dashboards/admin.html, dashboards/seller.html, dashboards/buyer.html

NO DEMO PRODUCTS
The marketplace intentionally shows no fake sample listings.
Seller listing creation saves only in this browser preview.

IMPORTANT LIMITATION
This is a front-end preview. Authentication, secure admin access,
Supabase persistence, payment processing, orders, delivery tracking,
disputes and payouts are not production-enabled. Do not use real
passwords or payment credentials. Connect and test the separate
ISOKO PLUS backend before deployment.


OFFICIAL CONTACT DETAILS
WhatsApp: https://wa.me/250784520912
Instagram: https://www.instagram.com/erick_gavana_films?srtk=MTFjNnd2aHNrbzBzOA==
YouTube: https://youtube.com/@erick-gavana?si=E4ynH0A4J12PK28d
Email: djeeyerick@gmail.com

The header and footer logo links return users to index.html. About and Contact pages
include the updated ISOKO PLUS information and official contact channels.


SUPABASE BACKEND CONNECTION
===========================
This build uses the Supabase project URL and publishable key supplied by the
ISOKO PLUS owner. The publishable key is intended for browser use; never place
a Supabase secret/service_role key in website files.

SETUP REQUIRED BEFORE AUTHENTICATION WORKS
1. Open https://supabase.com/dashboard and select the ISOKO PLUS project.
2. Open SQL Editor > New query.
3. Open SUPABASE_SETUP.sql from this package, copy all SQL, paste it in SQL
   Editor and press Run. Confirm the query succeeds.
4. In Supabase Authentication > URL Configuration, set Site URL to the final
   deployed website URL. Add the deployed URL and its wildcard path to
   Redirect URLs if required by your hosting setup.
5. Deploy the complete folder to hosting (GitHub Pages/Netlify/etc.) and use
   the deployed HTTPS URL to test. Do not test Supabase auth using file://.
6. Open Register, create a Buyer account or Seller account, and confirm the
   email if Supabase email confirmation is enabled. Then log in.
7. A Buyer is routed to dashboards/buyer.html. A Seller is routed to
   dashboards/seller.html. Seller listings are saved in Supabase with status
   pending; they are not publicly visible until an admin publishes them.

ADMIN ACCOUNT
-------------
Register the owner's account first. Then run the final UPDATE statement in
SUPABASE_SETUP.sql after replacing YOUR-ADMIN-EMAIL with the owner's exact
email address. Admin role is deliberately not offered on public registration.
Only the project owner should promote an account to admin.

CURRENT SCOPE / IMPORTANT
-------------------------
- Supabase email/password signup and login are connected.
- Buyer/Seller roles are created server-side from signup metadata, constrained
  to buyer or seller; the public form cannot create an admin.
- Dashboard access checks the user's profile role and database RLS policies.
- Seller product creation writes to the Supabase products table as pending.
- Public product pages read only published listings.
- Orders, checkout, payments, delivery, refunds, chat, seller payouts, and
  full admin moderation UI are not yet implemented. Do not accept real
  payments or claim a transaction is complete until those modules are built
  and tested.
