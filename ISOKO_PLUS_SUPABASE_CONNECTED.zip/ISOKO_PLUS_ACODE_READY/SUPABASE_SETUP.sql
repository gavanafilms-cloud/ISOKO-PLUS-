-- ISOKO PLUS: Supabase schema for authentication, profiles and marketplace listings
-- Run this entire file in Supabase > SQL Editor > New query > Run.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'buyer' check (role in ('buyer','seller','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.is_isoko_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.handle_new_isoko_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare requested_role text;
begin
  requested_role := coalesce(new.raw_user_meta_data->>'role', 'buyer');
  if requested_role not in ('buyer','seller') then
    requested_role := 'buyer';
  end if;

  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    requested_role
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_isoko on auth.users;
create trigger on_auth_user_created_isoko
after insert on auth.users
for each row execute procedure public.handle_new_isoko_user();

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  mode text not null check (mode in ('sale','rent')),
  category text not null,
  price numeric(14,2) not null check (price > 0),
  rental_period text check (rental_period in ('day','week','month')),
  location text not null default 'Rwanda',
  image_url text,
  description text,
  status text not null default 'pending' check (status in ('pending','published','rejected','sold','unavailable')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_status_created_idx
on public.products(status, created_at desc);
create index if not exists products_seller_idx
on public.products(seller_id);

alter table public.profiles enable row level security;
alter table public.products enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile"
on public.profiles for select
to authenticated
using (id = auth.uid() or public.is_isoko_admin());

drop policy if exists "Public can read published products and owners can read theirs" on public.products;
create policy "Public can read published products and owners can read theirs"
on public.products for select
to anon, authenticated
using (
  status = 'published'
  or seller_id = auth.uid()
  or public.is_isoko_admin()
);

drop policy if exists "Sellers can create pending products" on public.products;
create policy "Sellers can create pending products"
on public.products for insert
to authenticated
with check (
  seller_id = auth.uid()
  and status = 'pending'
  and exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'seller'
  )
);

drop policy if exists "Sellers can update their pending products" on public.products;
create policy "Sellers can update their pending products"
on public.products for update
to authenticated
using (
  seller_id = auth.uid()
  and exists (select 1 from public.profiles where id = auth.uid() and role = 'seller')
)
with check (seller_id = auth.uid() and status = 'pending');

drop policy if exists "Sellers can delete their pending products" on public.products;
create policy "Sellers can delete their pending products"
on public.products for delete
to authenticated
using (
  seller_id = auth.uid()
  and status = 'pending'
  and exists (select 1 from public.profiles where id = auth.uid() and role = 'seller')
);

drop policy if exists "Admins can manage all products" on public.products;
create policy "Admins can manage all products"
on public.products for all
to authenticated
using (public.is_isoko_admin())
with check (public.is_isoko_admin());

-- ADMIN SETUP:
-- 1) Register your own account through ISOKO PLUS.
-- 2) In Supabase > SQL Editor, run this command with your account email:
-- update public.profiles p set role = 'admin'
-- from auth.users u where p.id = u.id and u.email = 'YOUR-ADMIN-EMAIL';
--
-- Never make an admin role selectable on the public registration form.
